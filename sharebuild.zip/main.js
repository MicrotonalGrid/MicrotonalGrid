/* eslint-disable no-inner-declarations */
import SwitchSynth from "./switchSynth.js"
import Grid from "./grid.js"
import SynthConfig from "./synthConfig.js"
import Life from "./life.js"
import updateUrl from "./urlUpdater.js"

{
  document.cookie = "SameSite=none";
  console.log(document.cookie);
  let onOff = document.createElement("div");
  onOff.style.bottom = 0;
  onOff.style.right =0;
  onOff.textContent = "PLAY";
  onOff.className = "playButton";
  onOff.addEventListener('click',unmute, true);
  document.getElementById("matrix").appendChild(onOff); 
  let playing = false;
  
  let itervalMiliSec = 250;

  let westernSubdivisions = 12;
  let westernOffsets = [0,3,5,7,10,12,12+3,5+12,7+12,10+12,24,24+3,24+5,24+7,24+10,24+12];
  let westernOctave = 2;

  let bohlenSubdivisions = 13;
  let bohlenOffsets = [0,2,3,5,6,8,9,11,12,13,13+2,13+3,13+5,13+6,13+8,13+9];
  let bohlenOctave = 3;

  let arabOctave = 2;
  let arabSubdivisions = 24;
  let arabOffsets = [0,1.5*2,3*2,5*2,6.5*2,8*2,11*2,
                0+24,(1.5*2)+24,(3*2)+24,(5*2)+24,(6.5*2)+24,(8*2)+24,(11*2)+24,48,(1.5*2)+(24*2)];

  let rootNote = 220;
  let subdivisions = westernSubdivisions;
  let offsets = westernOffsets;
  let octave = westernOctave;

  let mySynth = new SwitchSynth(rootNote,subdivisions,offsets,octave,itervalMiliSec);
  let mySynthDisplay = new SynthConfig(rootNote,subdivisions,offsets,octave);

  let offsetDisplays = [];
  let offsetControls = [];
  let octaveDisplay;
  let subdivisionsDisplay;
  let rootNoteDisplay;
  mySynthDisplay.createDisplay(offsetDisplays,octaveDisplay,subdivisionsDisplay,rootNoteDisplay,offsetControls);

  let scrubber = document.createElement("div");
  scrubber.style.bottom = 0;
  scrubber.style.right = 142.5 + 'px';
  //scrubber.style.right = 800 - 95 + 'px';
  scrubber.className = 'scrubber';
  document.getElementById("matrix").appendChild(scrubber); 

  let currentIteration = 15;

  let myGrid = new Grid();
  let buttons = [];
  myGrid.createGrid(buttons);

  window.addEventListener("statechange",updateGridStateInUrl);
  window.addEventListener("offsetchange",updateOffsetNote);
  window.addEventListener("octavechange",updateOctave);
  window.addEventListener("subdivisionchange",updateSubdivision);

  let western;
  western = document.createElement("div");
  western.style.bottom = String(568)+"px";
  western.style.right = String(800-780)+"px";
  western.style.width = 100+"px";

  western.id = "western";
  western.className = "offsets";
  western.textContent = "12 tone"  ;
  western.style.textDecoration = "underline";
  western.addEventListener('mousedown',western12Click, false);
  document.getElementById("matrix").appendChild(western);  

  let bohlen;
  bohlen = document.createElement("div");
  bohlen.style.bottom = String(493)+"px";
  bohlen.style.right = String(800-780)+"px";
  bohlen.style.width = 100+"px";

  bohlen.id = "bohlen";
  bohlen.className = "offsets";
  bohlen.textContent = "BP 3^13"  ;
  bohlen.style.textDecoration = "underline";
  bohlen.addEventListener('mousedown',bp13Click, false);
  document.getElementById("matrix").appendChild(bohlen);  

  let arabic;
  arabic = document.createElement("div");
  arabic.style.bottom = String(530)+"px";
  arabic.style.right = String(800-780)+"px";
  arabic.style.width = 100+"px";

  arabic.id = "arabic";
  arabic.className = "offsets";
  arabic.textContent = "Arabic 24"  ;
  arabic.style.textDecoration = "underline";
  arabic.addEventListener('mousedown',arabicClick, false);
  document.getElementById("matrix").appendChild(arabic); 

  let liveStill ;
  liveStill = document.createElement("div");
  liveStill.style.bottom = String(180)+"px";
  liveStill.style.right = String(800-780)+"px";
  liveStill.style.width = 100+"px";
  liveStill.style.height = 50+"px";

  liveStill.textContent = "Conway's Life Mode";
  liveStill.className = "offsets";
  liveStill.id = "toogleConway";

  liveStill.addEventListener('click',liveDie, false);

  document.getElementById("matrix").appendChild(liveStill); 

  let conwayState = false;

  let liveState ;
  liveState = document.createElement("div");
  liveState.style.bottom = String(180-25)+"px";
  liveState.style.right = String(800-780)+"px";
  liveState.style.width = 100+"px";
  liveState.style.filter = "invert(1)";

  liveState.textContent = conwayState;
  liveState.className = "offsets";
  liveState.id = "deadOrAlive";

  document.getElementById("matrix").appendChild(liveState); 

  let loadState ;
  loadState = document.createElement("div");
  loadState.style.bottom = String(100)+"px";
  loadState.style.right = String(800-780)+"px";
  loadState.style.width = 100+"px";
  loadState.style.height = 50+"px";

  loadState.textContent = "Load State";
  loadState.className = "offsets";
  loadState.id = "loadState";

  loadState.addEventListener('click',loadStateEvent, true);

  document.getElementById("matrix").appendChild(loadState); 
 
  let saveState ;
  saveState = document.createElement("div");
  saveState.style.bottom = String(0)+"px";
  saveState.style.right = String(800-780)+"px";
  saveState.style.width = 100+"px";
  saveState.style.height = 100+"px";
  saveState.style.filter= "invert(1)";
  saveState.textContent = "Save State Using Clipboard";
  saveState.className = "offsets";
  saveState.id = "saveState";

  saveState.addEventListener('click',saveStateFunc, true);

  document.getElementById("matrix").appendChild(saveState); 

  function arabicClick(event)
  {
    subdivisions = arabSubdivisions;
    offsets = arabOffsets;
    octave = arabOctave;
    mySynth.updateAllConfig(octave,subdivisions,offsets);
    mySynthDisplay.updateDisplays(octave,subdivisions,offsets);
  }

  function bp13Click(event)
  {
    subdivisions = bohlenSubdivisions;
    offsets = bohlenOffsets;
    octave = bohlenOctave;
    mySynth.updateAllConfig(octave,subdivisions, offsets);
    mySynthDisplay.updateDisplays(octave,subdivisions,offsets);
  }

  function western12Click(event)
  {
    octave = westernOctave;
    subdivisions = westernSubdivisions;
    offsets = westernOffsets;
    mySynth.updateAllConfig(octave,subdivisions, offsets);
    mySynthDisplay.updateDisplays(octave,subdivisions,offsets);
  }

  function updateOffsetNote(event)
  {
    mySynth.updateSpecificOscillator(event.detail.index ,event.detail.subdivision);
  }

  function updateOctave(event)
  {
    octave = event.detail.octave;
    mySynth.updateOctave(event.detail.octave);
    mySynthDisplay.updateDisplays(octave,subdivisions,offsets);
  }

  function updateSubdivision(event)
  {
    subdivisions = event.detail.subdivision;

    mySynth.updateSubdivision(event.detail.subdivision);
    mySynthDisplay.updateDisplays(octave,subdivisions,offsets);
  }

  function unmute(event)
  { 
    event.stopPropagation();
    mySynth.createOscillators();
    mySynth.startOscillators();
    loadStateFunc();
    event.target.className = "playButtoff";
    event.target.textContent = "";
    playing = true;
    setInterval(eachTick, itervalMiliSec);
  }

  function liveDie(event)
  {
    conwayState = !conwayState;
    liveState.textContent = conwayState;
  }

  function unmuteSelectedNotes()
  {
    buttons[currentIteration].forEach(button => 
    {
      let currentIndex =   buttons[currentIteration].indexOf(button);
      if(button.className != 'matrixButtOff')
      {
        mySynth.connectSpecificOscillator(currentIndex);
      }
    });
  }

  function eachTick()
  {
    if(parseInt(scrubber.style.right.substring(0,scrubber.style.right.length-2)) > 145)
    {
      currentIteration++;
      //updatePreviousIteration();
      incrementBar(currentIteration);
    }
    else
    {
      currentIteration = 0;
      if (conwayState == true)
      {
        Life(buttons);
      }
      //updatePreviousIteration();
      resetBar();
    }
    unmuteSelectedNotes(currentIteration);
  }

  function incrementBar(positionNumber)
  {
    let referenceButton = buttons[positionNumber][0];
    let tem = referenceButton.style.right.substring(0,referenceButton.style.right.length-2);
    tem = parseInt(tem)-2.5;
    tem += "px";


    scrubber.style.right = tem;
  }

  function resetBar()
  {
    scrubber.style.right = 800-95 + 'px';
  }

  function updateGridStateInUrl(event) 
  {
    if(playing == true)
    {
      //console.log("inside if");
      let myElement = document.getElementById(event.detail.idOfButtonPressed);
      console.log("element id : " + myElement.id);
      if(myElement.className == 'matrixButtOff')
      {
        myElement.className  = 'matrixButtOn';
      }
      else
      {
        myElement.className  = 'matrixButtOff';
      }

      let gridState = saveGridToUrl();
      updateUrl("gridState", gridState);
    }
  }

  function loadStateEvent(event)
  {
    event.stopPropagation();
    loadStateFunc();
  }

  function loadStateFunc()
  {
    const url = new URL(window.parent.location);
    url.searchParams.forEach(processUrlParam);
    mySynth.updateAllConfig(octave,subdivisions,offsets);
    mySynthDisplay.updateDisplays(octave,subdivisions,offsets);
  }

  function processUrlParam(value , key)
  {
    switch(key)
    {
      case"gridState":
      {
        loadStateFromUrl(value);
        break;
      }
      case "offset00":
      case "offset01":
      case "offset02":
      case "offset03":
      case "offset04":
      case "offset05":
      case "offset06":
      case "offset07":
      case "offset08":
      case "offset09":
      case "offset10":
      case "offset11":
      case "offset12":
      case "offset13":
      case "offset14":
      case "offset15": 
      {
        let offsetIndex = Number(key.substring(6));
        offsets[offsetIndex] = value;
        break;
      }
      case "octaveDisplayText": 
      {
        octave = value;
        break;
      }
      case "subdivisionsDisplayText": {
        subdivisions = value;
        break;
      }
    }
  }

  function saveStateFunc(event)
  {
    event.stopPropagation();
    let gridState = saveGridToUrl();
    updateUrl("gridState", gridState);
    navigator.clipboard.writeText(window.parent.location); 
  }


  function loadStateFromUrl(text)
  {
    let arrayX= text.split("X");
    let stateInBinary = "";

    for(let myString of arrayX)
    {
      let interm = parseInt(myString,36).toString(2).padStart(16,"0");
      stateInBinary += parseInt(myString,36).toString(2).padStart(16,"0");
    }
    
    for (let i  = 0; i  < 16; i ++) 
    {
        for (let j = 0; j < 16; j++) 
        {
          if(stateInBinary[ ( i*16  )+j ] == "1")
          {
            buttons[i][j].className = "matrixButtOn";
          }
          else
          {
            buttons[i][j].className = "matrixButtOff";
          }   
        }                
    }

  }


  function saveGridToUrl()
  {
    let gridData = "";
    let returnText = "";
    for (let i  = 0; i  < 16; i ++) 
    {
      for (let j = 0; j < 16; j++) 
      {
        if(buttons[i][j].className == "matrixButtOn")
        {
          gridData+="1";
        }
        else
        {
          gridData+="0";
        }   
      } 
      returnText +=parseInt(gridData , 2).toString(36) ;

      if(i != 15 ) 
        {
          returnText +=    "X" ; 
          
          gridData = "";
        }     
    }

    let toReturn  = returnText;

    return toReturn;
  }

}